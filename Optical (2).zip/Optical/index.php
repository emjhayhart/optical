<?php
 session_start();
 

include 'config/connection.php';
if(isset($_POST["login"]))
{
  $user = $_POST["patients_user"];
  $pass = $_POST["password"]; 

  $password = md5($pass);
  
 $login = mysqli_query($conn,"SELECT * FROM patients WHERE patients_user= '" .$user. "' and patients_pass = '" .$password. "'");
 $row=mysqli_fetch_array($login);  
 
 if($row){
 $_SESSION['id'] = $row['patients_id'];
 $_SESSION['display_name'] = $row['patients_name'];

 echo '<script>windows: location="user_appointment.php"</script>';
 }
  else {
    $_SESSION['message'] = "Username / Password is Incorrect!";
  $_SESSION['msg_type'] = "success";
    header ("location: index.php");
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login - Sayson Almaras Optical Management System</title>

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

  <style>
  	
  	.login-box {
    	width: 430px;
	}
  
#system-logo {
    width: 5em !important;
    height: 5em !important;
    object-fit: cover;
    object-position: center center;
}
  </style>
</head>
<body class="hold-transition login-page dark-mode">
<div class="login-box">
  <div class="login-logo mb-4">
    <img src="user_images/logo.com.png" class="img-thumbnail p-0 border rounded-circle" id="system-logo">
    <div class="text-center h2 mb-0">Sayson Almaras Optical Management System</div>
  </div>
  <!-- /.login-logo -->
  <div class="card card-outline card-primary rounded-0 shadow">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Please enter your Email and Password</p>
      <form method="post">
        <div class="input-group mb-3">
          <input type="patient_user" class="form-control form-control-lg rounded-0 autofocus" 
          placeholder="Username" id="patients_user" name="patients_user">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control form-control-lg rounded-0" 
          placeholder="Password" id="pass_word" name="password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <button name="login" type="submit" class="btn btn-primary rounded-0 btn-block">Sign In</button>
          </div>
          <!-- /.col -->
        </div>

        <div class="row">
          <div class="col-md-12">
            <p class="text-danger">

            </p>
          </div>
        </div>
      </form>

        <a href="#" data-toggle="modal" data-target="#signmodal" class="btn btn-primary rounded-0 btn-block">Sign Up</a>
        <div align="center">
         <a href="forgot.php?step=1">Forgot Password?</a>
       </div>
      <div class="modal fade" id="signmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Register as a Patient</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div class="modal-body">
            <div class="card-body">
              <form method="post" action="user_sign_process.php" enctype="multipart/form-data">
                <div class="row">
                    <label>Patients Name</label>
                    <input type="text" id="patientname" name="patientname" required="required"
                            class="form-control form-control-sm rounded-0" />
                    <label>Address</label>
                    <input type="text" id="address" name="address" required="required"
                            class="form-control form-control-sm rounded-0"/>
                    <label>Contact No.</label>
                    <input type="text" id="contact" name="contact" required="required"
                            class="form-control form-control-sm rounded-0" />
                    <label>Gender</label>
                    <select class="form-control form-control-sm rounded-0" id="gender" name="gender"> <?php echo getGender();?> 
                </select> 
                    <label>Username</label>
                    <input type="patients_user" id="patients_user" name="patients_user" required="required"
                            class="form-control form-control-sm rounded-0"/>
                    <label>Password</label>
                    <input type="password" id="password" name="password" required="required"
                            class="form-control form-control-sm rounded-0" />
                            
                </div>
                <div class="clearfix">&nbsp;</div>
                  <button type="submit" id="btnsubmit" name="btnsubmit" class="btn btn-primary btn-sm btn-flat btn-block">Submit</button>

                </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  </div>
</div>
<?php include 'config/data_js.php'; 
include 'config/js.php';

$message = '';
if(isset($_GET['message'])) {
  $message = $_GET['message'];
}
?>

<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script>
   var message = '<?php echo $message;?>';

  if(message !== '') {
    showCustomMessage(message);
  }
  
  $('#date_of_birth').datetimepicker({
        format: 'L'
    });

</script>
</body>
</html>
<?php 

function getGender($gender = '') {
  $data = '<option value="">Select Gender</option>';
  
  $arr = array("Male", "Female");

  $i = 0;
  $size = sizeof($arr);

  for($i = 0; $i < $size; $i++) {
    if($gender == $arr[$i]) {
      $data = $data .'<option selected="selected" value="'.$arr[$i].'">'.$arr[$i].'</option>';
    } else {
    $data = $data .'<option value="'.$arr[$i].'">'.$arr[$i].'</option>';
    }
  }

  return $data;
}

?>
