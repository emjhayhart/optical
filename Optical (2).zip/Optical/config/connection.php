<?php
$conn = mysqli_connect('localhost', 'root', '',"saoms_db");
   if (!$conn)
    {
   die('Could not connect: ' . mysql_error());
  } 