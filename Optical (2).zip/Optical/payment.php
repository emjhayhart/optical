<?php 
session_start();
include 'config/connection.php';

$message = '';

if(isset($_POST['btnsave'])){

  $patientid = $_POST['patient'];
  $checkup = $_POST['checkup'];
  $eyewear = $_POST['Eyewear'];

  mysqli_query($conn, "INSERT INTO payment (pay_patientsID, pay_checkup, pay_eyeID) VALUES ('$patientid', '$checkup', '$eyewear')");

  $message = "Payment Save Successfully!";
header("location:congratulations.php?goto_page=payment.php&message=$message");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <?php include 'config/css.php';?>
 <?php include 'config/data_css.php';?>
 <title>Payment - SAOMS</title>
</head>
<body class="hold-transition sidebar-mini dark-mode layout-fixed layout-navbar-fixed">
 <div class="wrapper">

    <?php include 'include/header.php';
include 'include/sidebar.php';?> 
    <div class="content-wrapper">

      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Payment</h1>
            </div>
          </div>
        </div>
      </section>

      <section class="content">
        <div class="card card-outline card-primary rounded-0 shadow">
          <div class="card-header">
            <h3 class="card-title">Add Payment</h3>
            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-minus"></i>
              </button>
            </div>
          </div>

          <div class="card-body">
            <form method="post">
             <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10">
                <label>Patients Name</label>
                <select id="patient" name="patient" class="form-control form-control-sm rounded-0" 
                  required="required">
                  <option selected></option>
                  <?php 
                    $query = mysqli_query($conn, "SELECT * FROM patients, check_up WHERE patients.patients_id = check_up.check_patientsID");
                    while($row = mysqli_fetch_array($query)):;
                  ?>
                  <option value="<?php echo $row['patients_id']; ?>"><?php echo $row['patients_name']; ?></option>
                  <?php endwhile; ?>
                </select>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10">
                <label>Check up</label>
                <input type="text" name="checkup" id="checkup" class="form-control form-control-sm rounded-0" required="required" value="500" />
              </div>
              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10">
                <label>Eyewear</label>
                <select id="Eyewear" name="Eyewear" class="form-control form-control-sm rounded-0" 
                  required="required">
                  <option selected></option>
                  <?php 
                    $query1 = mysqli_query($conn, "SELECT * FROM eyewear_sell");
                    while($row1 = mysqli_fetch_array($query1)):;
                  ?>
                  <option value="<?php echo $row1['eye_id']; ?>"><?php echo $row1['eye_name']; ?></option>
                  <?php endwhile; ?>
              </select>
              </div>
              <div class="col-lg-1 col-md-2 col-sm-2 col-xs-2">
                <label>&nbsp;</label>
                <button type="submit" id="btnsave" 
                name="btnsave" class="btn btn-primary btn-sm btn-flat btn-block">Save</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card card-outline card-primary rounded-0 shadow">
        <div class="card-header">
          <h3 class="card-title">All Payment</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body">
         <div class="row table-responsive">
            <table id="checkup" 
                  class="table table-striped dataTable table-bordered dtr-inline" 
                  role="grid" aria-describedby="all_medicines_info">
                  <colgroup>
                    <col width="5%">
                    <col width="17%">
                    <col width="23%">
                    <col width="10%">
                    <col width="10%">
                    <col width="10%">
                    <col width="10%">
                    <col width="10%">
                  </colgroup>

                  <thead>
                    <tr>
                     <th class="text-center">S.No</th>
                     <th>Patients Name</th>
                     <th>Address</th>
                     <th>Contact No.</th>
                     <th>Check Up</th>
                     <th>Eyewear</th>
                     <th>Total Payment</th>
                     <th class="text-center">Action</th>
                   </tr>
                 </thead>
                 <?php 
                  $queryy = mysqli_query($conn, "SELECT patients.patients_id, patients.patients_name, patients.patients_address, patients.patients_contact, payment.pay_checkup, payment.pay_eyeID, payment.pay_id, eyewear_sell.eye_price FROM patients INNER JOIN payment INNER JOIN eyewear_sell WHERE patients.patients_id = payment.pay_patientsID AND payment.pay_eyeID = eyewear_sell.eye_id");
                  while ($roww = mysqli_fetch_array($queryy)) {
                    $total = $roww['pay_checkup'] + $roww['eye_price'];
                  ?>
                 <tbody>
                   <tr>
                     <td class="text-center"><?php echo $roww['pay_id'];?></td>
                     <td><?php echo $roww['patients_name'];?></td>
                     <td><?php echo $roww['patients_address'];?></td>
                     <td><?php echo $roww['patients_contact'];?></td>
                     <td><?php echo $roww['pay_checkup'];?></td>
                     <td><?php echo $roww['eye_price'];?></td>
                     <td><?php echo $total; ?></td>
                     <td class="text-center">
                      <a href="#?id=<?php echo $roww['pay_id'];?>" 
                       class="btn btn-primary btn-sm btn-flat">
                       <i class="fa fa-edit"></i>
                     </a>
                     <a href="print_payment.php?id=<?php echo $roww['pay_id'];?>" 
                       class="btn btn-primary btn-sm btn-flat">
                       <i class="fa fa-print"></i>
                     </a>
                   </td>
                 </tr>
               <?php }; ?>
             </tbody>
           </table>
         </div>
        </div>
      </div>
    </div>  
  </div>
</section>
</div>
<?php 
include 'include/footer.php';

$message = '';
if(isset($_GET['message'])) {
  $message = $_GET['message'];
}
?>  
</div>

<?php include 'config/js.php'; ?>
<?php include 'config/data_js.php'; ?>
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script type="text/javascript">
   var message = '<?php echo $message;?>';

  if(message !== '') {
    showCustomMessage(message);
  }
  showMenuSelected("#mnu_payment");

  $('#date_of_birth').datetimepicker({
        format: 'L'
    });
  $(document).ready(function(){
    $('.table').dataTable();
  });
</script>
</body>
</html>