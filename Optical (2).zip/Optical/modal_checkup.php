<label>Patients Name</label>
<select id="patient" name="patient" class="form-control form-control-sm rounded-0" required="required">
  <option selected></option>
  <?php 
    $query = mysqli_query($conn, "SELECT * FROM patients");
    while($row = mysqli_fetch_array($query)):;
  ?>
    <option value="<?php echo $row['patients_id']; ?>"><?php echo $row['patients_name']; ?></option>
     <?php endwhile; ?>
</select>

<label>Findings</label>
<input type="text" name="findings" class="form-control form-control-sm rounded-0" required="required">

<label>Prescription</label>
<select id="prescription" name="prescription" class="form-control form-control-sm rounded-0" required="required">
  <option selected></option>
  <?php 
    $query2 = mysqli_query($conn, "SELECT * FROM medicine");
    while($row2 = mysqli_fetch_array($query2)):;
  ?>
   <option value="<?php echo $row2['medi_name']; ?>"><?php echo $row2['medi_name']; ?></option>
    <?php endwhile; ?>
</select>