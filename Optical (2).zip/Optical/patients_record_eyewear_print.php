<?php 
session_start();
include 'config/connection.php';

$id = $_REQUEST['id'];

$result = mysqli_query($conn,"SELECT * FROM eyewear_sell where eye_id ='$id'");
while($row = mysqli_fetch_array($result)){
	$eyeid = $row['eye_id'];
	$eyename = $row['eye_name'];
	$eyeprice = $row['eye_price'];
}

?>

<!DOCTYPE html>
<html>
<head>
	<?php include 'config/css.php';?>
 	<?php include 'config/data_css.php';?>
	<title>Print Checkup - SAOMS</title>
	<script>
			function printDiv(data) {
			      var printContents = document.getElementById('data').innerHTML;    
			   var originalContents = document.body.innerHTML;      
			   document.body.innerHTML = printContents;     
			   window.print();     
			   document.body.innerHTML = originalContents;
			   }
			</script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
<div class="wrapper">
<?php include 'include/header.php';
include 'include/sidebar.php';?> 
	<div class="content-wrapper">
		<section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Print Checkup</h1>
            </div>
          </div>
        </div>
      </section>

      <section class="content">
      	<div class="card card-outline card-primary rounded-0 shadow">
      	  <div class="card-header">
            <h3 class="card-title">Print</h3>
            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-minus"></i>
              </button>
            </div>
          </div>
      	</div>
      </section>

      <div class="card-body">
				<style type="text/css">
			#data { margin: 0 auto; width:450px; border:#066 thin ridge; height:500px; border: solid;}}

			</style>
			<div id="data">
			<center>
				
			<h5><center><b>Sayson Almaras Optical Clinic</b></center></h5>
			<p><b>12 Pres. S. Osmena St., Suba, Bantayan Island</b></p>
			<p><b> Phone: 0939 597 5081 </b></p>
			<h2><strong>Claim Slip</strong></h2>
			<i style="text-align:right; margin-left:150px;"><p><b>Date: </b><?php $date=date('y/m/d'); echo $date;?></p></i>
			</center>
			<div id="context">
			<table class="table table-striped table-bordered">
				<tr><td>Eyewear Name:</td><td><b><?php echo $eyename; ?></b></td></tr>
				<tr><td>Amount:</td><td><b><?php echo $eyeprice; ?></b></td></tr>
				<tr><td colspan="4"><center>Signature:_____________________________</center></td></tr>	 
			</table>
							<p><center>"Sayson-Almaras Optical Clinic is the premier vision care clinic in the Island of Bantayan since 1997."</center></p>

			</div>
			</div>
			<div class="row">
				<label></label>
			</div>
			<CENTER><button type="button"  class="btn btn-default " onclick="printDiv(data)"><span
			class=" glyphicon glyphicon-print"></span>&nbsp;Print Slip</button>&nbsp;<a href="patients_record.php"><button class="btn btn-danger"><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;Go back</button></a></CENTER>
      </div>
	</div>
<?php include 'include/footer.php'; ?> 
</div>
<?php include 'config/js.php'; ?>
<?php include 'config/data_js.php'; ?>
<script>
	$(function(){
		showMenuSelected("#mnu_patients", "#mi_record");
	})
</script>
</body>
</html>