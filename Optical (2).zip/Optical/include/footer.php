<footer class="main-footer fixed-bottom">
    <strong>Copyright &copy; <?php echo date('Y');?> 
    <a href="./">Sayson Almaras Optical Management System</a>.</strong> All rights reserved.
    <div class="float-right d-sm-block">
      SAOMS
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>