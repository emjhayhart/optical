<?php 

include 'config/connection.php';

$message = '';

if(isset($_POST['save_Patient'])){

	$patientName = $_POST['patient_name'];
	$address = $_POST['address'];
	$gender = $_POST['gender'];
	$contactNo = $_POST['phone_number'];

	$password = md5('pass123');

	$result = mysqli_query($conn, "INSERT INTO patients (patients_name, patients_address, patients_contact, patients_gender, patients_user, patients_pass) VALUES ('$patientName', '$address', '$contactNo', '$gender', '$contactNo', '$password')");

	
	$message = "Add Patient Successfully!";
	header("location:congratulations.php?goto_page=patients.php&message=$message");
};
 ?>
