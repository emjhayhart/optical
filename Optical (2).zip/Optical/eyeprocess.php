<?php
include 'config/connection.php';

$message = '';

if(isset($_POST['save_eyewear'])){

  $eyeglass = $_POST['eyeglasses_name'];
  $stock = $_POST['stocks'];
  $price = $_POST['price'];

   $result = mysqli_query($conn, "INSERT INTO eyeglasses (eye_name, eye_stock, eye_price, eye_wearID) VALUES ('$eyeglass','$stock','$price','1')");

$message = "New Eyeglasses Successfully!";
header("location:congratulations.php?goto_page=eyeglasses.php&message=$message");
  

};

?>