<?php
session_start();

include 'config/connection.php';


?>

<!DOCTYPE html>
<html lang="en">
<head>
 <?php include 'config/css.php';?>

 
 <?php include 'config/data_css.php';?>
 <title>History - SAOMS</title>
</head>
<body class="hold-transition sidebar-mini dark-mode layout-fixed layout-navbar-fixed">
  <!-- Site wrapper -->
  <div class="wrapper">
    <?php include 'include/header.php';
include 'include/sidebar.php';?>  
    <div class="content-wrapper">
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>History</h1>
            </div>
          </div>
        </div>
      </section>

    <section class="content">
      <div class="card card-outline card-primary rounded-0 shadow">
        <div class="card-header">
          <h3 class="card-title">Eyewear</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            
          </div>
        </div>
        <div class="card-body">
         <div class="row table-responsive">
          <?php $query = mysqli_query($conn, "SELECT * FROM payment, eyewear_sell WHERE payment.pay_eyeID = eyewear_sell.eye_id");
          while($row = mysqli_fetch_array($query)){
            $eyewear[] = $row['eye_price'];
            $eyename[] = $row['eye_name'];
          }
          ?>
          <canvas id="chart_bar" style="width:60%; height:20%;"></canvas>
         </div>
        </div>
      </div>
    </section>
  </div>
<?php 
include 'include/footer.php';

$message = '';
if(isset($_GET['message'])) {
  $message = $_GET['message'];
}
?>  
</div>

<?php include 'config/js.php'; ?>
<?php include 'config/data_js.php'; ?>
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<script src="plugins/chart.js/chart.min.js"></script>
<script src="plugins/chart.js/chart.js"></script>
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

<script>
  showMenuSelected("#mnu_history");

  var message = '<?php echo $message;?>';

  if(message !== '') {
    showCustomMessage(message);
  }
  $('#date_message').datetimepicker({
        format: 'L'
    })
  $(document).ready(function(){
    $('#all_appoint').dataTable();
  })

  var ctx = document.getElementById("chart_bar").getContext('2d');
  var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels:<?php echo json_encode($eyename); ?>,
      datasets:[{
        backgroundColor: [
          "#5969ff",
          "#ff407b",
          "#25d5f2",
          "#ffc750",
          "#2ec551",
          "#7040fa",
          "#ff004e",
        ],
        data: <?php echo json_encode($eyewear); ?>,
      }]
    },
    options: {
      legend: {
        display: true,
        position: 'bottom',

        labels: {
          fontColor: '#71748d',
          fontFamily: 'Circular Std Book',
          fontSize: 14,
        }
      },
    }
  })

</script>
</body>
</html>