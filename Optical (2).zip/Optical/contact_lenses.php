<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
 <?php include 'config/css.php';?>

 
 <?php include 'config/data_css.php';?>
 <title>Contact Lenses - SAOMS</title>
</head>
<body class="hold-transition sidebar-mini dark-mode layout-fixed layout-navbar-fixed">
  <!-- Site wrapper -->
  <div class="wrapper">
    <!-- Navbar -->
    <?php include 'include/header.php';
include 'include/sidebar.php';?>  
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Contact Lenses</h1>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>
      <!-- Main content -->
      <section class="content">
        <!-- Default box -->
        <div class="card card-outline card-primary rounded-0 shadow">
          <div class="card-header">
            <h3 class="card-title">Add Contact Lenses</h3>
            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-minus"></i>
              </button>
            </div>
          </div>
          <div class="card-body">
            <form method="post" action="contact_lenses_process.php" enctype="multipart/form-data">
             <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10">
                <label>Contact Lense Name</label>
                <input type="text" id="lens_name" name="lens_name" required="required"
                class="form-control form-control-sm rounded-0" />
              </div>
              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10">
                <label>Price</label>
                <input type="text" id="lens_price" name="lens_price" required="required"
                class="form-control form-control-sm rounded-0" />
              </div>
              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10">
                <label>Stocks</label>
                <input type="text" id="lens_stocks" name="lens_stocks" required="required"
                class="form-control form-control-sm rounded-0" />
              </div>
              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10">
                <label></label>
                <input type="file" id="file" name="file" required="required"
                class="form-control form-control-sm rounded-0" />
              </div>
              <div class="col-lg-1 col-md-2 col-sm-2 col-xs-2">
                <label>&nbsp;</label>
                <button type="submit" id="submit" 
                name="submit" class="btn btn-primary btn-sm btn-flat btn-block">Save</button>
              </div>
            </div>
          </form>
        </div>

      </div>
      <!-- /.card -->
    </section>
    <section class="content">
      <!-- Default box -->
      <div class="card card-outline card-primary rounded-0 shadow">
        <div class="card-header">
          <h3 class="card-title">All Contact Lenses</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            
          </div>
        </div>
        <div class="card-body">
          <div class="row">
            <?php 
              $query = $conn->query("SELECT * FROM eyewear_sell WHERE eye_wearID = '3' ORDER BY eye_id DESC");
              while($row = $query->fetch_assoc()):;
              $imageURL = 'user_images/'.$row["eye_picture"];

            ?>
            <div class="col-lg-3 col-3">
              <div class="small-box bg-info">
                <div class="inner">
                <img src="<?php echo $imageURL; ?>" width="40%" hieght="40%" alt="" />
                <h4><?php echo $row['eye_name']; ?></h4>
                <p>Price: <?php echo $row['eye_price']; ?></p>
                <div class="icon">
                  <?php 

                  $query1 = mysqli_query($conn, "SELECT count(pay_eyeID) AS payID FROM payment WHERE pay_eyeID = 'eyeid'");
                  $rw = mysqli_fetch_array($query1);
                  $stock = $rw['payID'];
                  ?>
                  <i style="font-size: 50px; color: white;"><?php echo $totalStock = $row['eye_stock'] - $stock; ?></i>
                </div>
                </div>
              </div>
            </div>
            <?php endwhile; ?>
          </div>
</div>

<!-- /.card-footer-->
</div>
<!-- /.card -->

</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php 
include 'include/footer.php';

$message = '';
if(isset($_GET['message'])) {
  $message = $_GET['message'];
}
?>  
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php include 'config/js.php'; ?>
<?php include 'config/data_js.php'; ?>


<script>
  showMenuSelected("#mnu_eyewear", "#mi_contact_lenses");

  var message = '<?php echo $message;?>';

  if(message !== '') {
    showCustomMessage(message);
  }

  $(function () {
    $("#all_medicines").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#all_medicines_wrapper .col-md-6:eq(0)');
    
  });

  $(document).ready(function() {

    $("#medicine_name").blur(function() {
      var medicineName = $(this).val().trim();
      $(this).val(medicineName);

      if(medicineName !== '') {
        $.ajax({
          url: "ajax/check_medicine_name.php",
          type: 'GET', 
          data: {
            'medicine_name': medicineName
          },
          cache:false,
          async:false,
          success: function (count, status, xhr) {
            if(count > 0) {
              showCustomMessage("This medicine name has already been stored. Please choose another name");
              $("#save_medicine").attr("disabled", "disabled");
            } else {
              $("#save_medicine").removeAttr("disabled");
            }
          },
          error: function (jqXhr, textStatus, errorMessage) {
            showCustomMessage(errorMessage);
          }
        });
      }

    });    
  });
</script>
</body>
</html>