<?php 
session_start();

include 'config/connection.php';

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php include 'config/css.php'; ?>
	<?php include 'config/data_css.php'; ?>
	<link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
	<title>Patients - SAOMS</title>
</head>
<body class="hold-transition sidebar-mini dark-mode layout-fixed layout-navbar-fixed">
<div class="wrapper">
<?php
	include 'include/header.php';
	include 'include/sidebar.php';
?>
	<div class="content-wrapper">
		<section class="content-header">
			<div class="container-fluid">
				<div class="row md-2">
					<div class="col-sm-6">
						<h1>Patients</h1>
					</div>
				</div>
			</div>
		</section>
		<section class="content">
			<div class="card card-outline card-primary rounded-0 shadow">
				<div class="card-header">
					<h3 class="card-title">Add Patients</h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
							<i class="fas fa-minus"></i>
						</button>
					</div>
				</div>
				<div class="card-body">
					<form method="post" action="addpatients.php">
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-10">
								<label>Patient Name</label>
								<input type="text" id="patient_name" name="patient_name" required="required"
                				class="form-control form-control-sm rounded-0"/>
							</div>
							<br>
							<br>
							<br>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-10">
								<label>Address</label> 
                				<input type="text" id="address" name="address" required="required" class="form-control form-control-sm rounded-0"/>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-10">
				         <label>Phone Number</label>
				         <input type="text" id="phone_number" name="phone_number" required="required"
				                class="form-control form-control-sm rounded-0"/>
				      </div>
				      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10">
				        <label>Gender</label>
				        <select class="form-control form-control-sm rounded-0" id="gender" name="gender"> <?php echo getGender();?>	
				        </select>    
				      </div>  
						</div>
						<div class="clearfix">&nbsp;</div>
						<div class="col-lg-1 col-md-2 col-sm-2 col-xs-12">
			        <button type="submit" id="save_Patient" name="save_Patient" class="btn btn-primary btn-sm btn-flat btn-block">Save</button>
			      </div>
					</form>
				</div>
			</div>
		</section>
		<br/>
     <section class="content">
      <!-- Default box -->
      <div class="card card-outline card-primary rounded-0 shadow">
        <div class="card-header">
          <h3 class="card-title"> Patient History</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            
          </div>
        </div>
        <div class="card-body">
            <div class="row table-responsive">
              <table id="all_patients" 
              class="table table-striped dataTable table-bordered dtr-inline" 
               role="grid" aria-describedby="all_patients_info">
              
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Patient Name</th>
                    <th>Address</th>
                    <th>Phone Number</th>
                    <th>Gender</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  <?php 
                  include 'config/connection.php';
                  $query = mysqli_query($conn, "SELECT * FROM patients");
                  while($row = mysqli_fetch_array($query)):
                  	$count = $row['patients_id'];
                  ?>
                  <tr>
                    <td><?php echo $count; ?></td>
                    <td><?php echo $row['patients_name'];?></td>
                    <td><?php echo $row['patients_address'];?></td>
                    <td><?php echo $row['patients_contact'];?></td>
                    <td><?php echo $row['patients_gender'];?></td>
                    <td>
                      <a href="updatepatients.php?id=<?php echo $row['patients_id'];?>" class = "btn btn-primary btn-sm btn-flat">
                      <i class="fa fa-edit"></i>
                      </a>
                    </td>
                   
                  </tr>
                <?php
                endwhile;
                ?>
                </tbody>
              </table>
            </div>
        </div>
     		<?php include 'include/footer.php'; ?>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

   
    </section>
	</div>
</div>
<?php
 include 'config/js.php';
 include 'config/data_js.php';

 $message = '';
if(isset($_GET['message'])) {
  $message = $_GET['message'];
}
?>

<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script type="text/javascript">
	showMenuSelected("#mnu_patients", "#mi_patients");

	var message = '<?php echo $message;?>';

  if(message !== '') {
    showCustomMessage(message);
  }

	$('#date_of_birth').datetimepicker({
        format: 'L'
    });
	$(document).ready(function(){
		$('.table').dataTable();
	});
</script>
</body>
</html>
<?php 

function getGender($gender = '') {
	$data = '<option value="">Select Gender</option>';
	
	$arr = array("Male", "Female");

	$i = 0;
	$size = sizeof($arr);

	for($i = 0; $i < $size; $i++) {
		if($gender == $arr[$i]) {
			$data = $data .'<option selected="selected" value="'.$arr[$i].'">'.$arr[$i].'</option>';
		} else {
		$data = $data .'<option value="'.$arr[$i].'">'.$arr[$i].'</option>';
		}
	}

	return $data;
}

?>