<?php
session_start();
include 'config/connection.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
 <?php include 'config/css.php';?>

 
 <?php include 'config/data_css.php';?>
 <title>Message - SAOMS</title>
</head>
<body class="hold-transition sidebar-mini dark-mode layout-fixed layout-navbar-fixed">
  <!-- Site wrapper -->
  <div class="wrapper">
    <?php include 'include/header.php';
include 'include/sidebar.php';?>  
    <div class="content-wrapper">
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Message</h1>
            </div>
          </div>
        </div>
      </section>

    <section class="content">
      <div class="card card-outline card-primary rounded-0 shadow">
        <div class="card-header">
          <h3 class="card-title">All Message</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            
          </div>
        </div>
        <div class="card-body">
         <div class="row table-responsive">

          <table id="all_appoint" 
          class="table table-striped dataTable table-bordered dtr-inline" 
          role="grid" aria-describedby="all_medicines_info">
          <colgroup>
            <col hidden width="5%">
            <col width="30%">
            <col width="60%">
            <col width="10%">
          </colgroup>

          <thead>
            <tr>
             <th hidden class="text-center">S.No</th>
             <th>Patient's Name</th>
             <th>Message</th>
             <th class="text-center">Action</th>
           </tr>
         </thead>
         <?php 
          $query = mysqli_query($conn, "SELECT * FROM message, patients WHERE message.mess_patientsID = patients.patients_id");
          while ($row = mysqli_fetch_array($query)) {

          ?>
         <tbody>
           <tr>
             <td hidden class="text-center"><?php echo $row['mess_id'];?></td>
             <td><?php echo $row['patients_name'];?></td>
             <td><?php echo $row['mess_description'];?></td>
             <td>
              <a href="#?id=<?php echo $row['mess_id'];?>" 
               class="btn btn-danger btn-sm btn-flat">
               <i class="fa fa-trash"></i>
             </a>
           </td>
         </tr>
       <?php }; ?>
     </tbody>
   </table>
 </div>
</div>
</div>
</section>
</div>
<?php 
include 'include/footer.php';

$message = '';
if(isset($_GET['message'])) {
  $message = $_GET['message'];
}
?>  
</div>

<?php include 'config/js.php'; ?>
<?php include 'config/data_js.php'; ?>
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

<script>
  showMenuSelected("#mnu_patients", "#mi_message");

  var message = '<?php echo $message;?>';

  if(message !== '') {
    showCustomMessage(message);
  }
  $('#date_message').datetimepicker({
        format: 'L'
    })
  $(document).ready(function(){
    $('#all_appoint').dataTable();
  })
</script>
</body>
</html>