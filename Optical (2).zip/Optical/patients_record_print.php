<?php 
session_start();
include 'config/connection.php';

$id = $_REQUEST['id'];

$result = mysqli_query($conn,"SELECT * FROM check_up where check_id ='$id'");
while($row = mysqli_fetch_array($result)){
	$findings = $row['check_findings'];
	$prescription = $row['check_prescription'];
	$patientid = $row['check_patientsID'];
}

$query = mysqli_query($conn, "SELECT * FROM patients WHERE patients_id = '$patientid'");
$row1 = mysqli_fetch_array($query);
if(!$query)
{
	die("Error: Data not found..");
	}

	$patientID = $row1['patients_id'];
	$patientName = $row1['patients_name'];
	$patientAdd = $row1['patients_address'];
	$patientcon = $row1['patients_contact'];
	$patientgen = $row1['patients_gender'];
?>

<!DOCTYPE html>
<html>
<head>
	<?php include 'config/css.php';?>
 	<?php include 'config/data_css.php';?>
	<title>Print Checkup - SAOMS</title>
	<script>
			function printDiv(data) {
			      var printContents = document.getElementById('data').innerHTML;    
			   var originalContents = document.body.innerHTML;      
			   document.body.innerHTML = printContents;     
			   window.print();     
			   document.body.innerHTML = originalContents;
			   }
			</script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
<div class="wrapper">
<?php include 'include/header.php';
include 'include/sidebar.php';?> 
	<div class="content-wrapper">
		<section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Print Record</h1>
            </div>
          </div>
        </div>
      </section>

      <section class="content">
      	<div class="card card-outline card-primary rounded-0 shadow">
      	  <div class="card-header">
            <h3 class="card-title">Print</h3>
            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-minus"></i>
              </button>
            </div>
          </div>
      	</div>
      </section>

      <div class="card-body">
				<style type="text/css">
			#data { margin: 0 auto; width:1000px; border:#066 thin ridge; height:520px; border: solid;}

			</style>
			<div id="data">
			<center>
				<p><center>"Sayson-Almaras Optical Clinic is the premier vision care clinic in the Island of Bantayan since 1997."</center></p>
			<h5><center><b>Sayson Almaras Optical Clinic</b></center>
			<p><b>12 Pres. S. Osmena St., Suba, Bantayan Island</b></p>
			<p><b> Phone: 0939 597 5081 </b></p>
			<h2><strong><b>Medical Record</b></strong></h2>
		 </b><i style="text-align:right; margin-left:250px;"><p><b>Date: </b><?php $date=date('y/m/d'); echo $date;?></p></i>
			</center>
			<div id="context">
				<div class="row">
					<div class="col-lg-8 col-8">
						&nbsp;&nbsp;&nbsp;&nbsp;<label>Patient Name: <?php echo $patientName; ?></label>
					</div>
					<div class="col-lg-3 col-3">
						<label>Gender: <?php echo $patientgen; ?></label>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-8 col-8">
						&nbsp;&nbsp;&nbsp;&nbsp;<label>Address: <?php echo $patientAdd; ?></label>
					</div>
					<div class="col-lg-4 col-4">
						<label>Phone No.: <?php echo $patientcon; ?></label>
					</div>
				</div>
			<table class="table table-striped table-bordered">

			<tr><td bordercolor="#000000">Findings: </td><td><b><i> <?php echo $findings;?></i></b></td><td bordercolor="#000000">Prescription: </td><td><b><i><?php echo $prescription; ?></i></b></td></tr>
				<br><br>
				<tr><td colspan="4"><center>Signature:_____________________________</center></td></tr>	 
			</table>
			</div>
			</div>
			<div class="row">
				<label></label>
			</div>
			<CENTER><button type="button"  class="btn btn-default " onclick="printDiv(data)"><span
			class=" glyphicon glyphicon-print"></span>&nbsp;Print Record</button>&nbsp;<a href="patients_record.php"><button class="btn btn-danger"><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;Go back</button></a></CENTER>
      </div>
	</div>
<?php include 'include/footer.php'; ?> 
</div>
<?php include 'config/js.php'; ?>
<?php include 'config/data_js.php'; ?>
<script>
	$(function(){
		showMenuSelected("#mnu_patients", "#mi_record");
	})
</script>
</body>
</html>