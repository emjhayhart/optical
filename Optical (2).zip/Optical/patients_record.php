<?php
session_start();

include 'config/connection.php';

$message = '';

if(isset($_POST['save_appointment'])){

  $patient_id = $_POST['patient_id'];
  $message = $_POST['message'];
  $datemessage = $_POST['date_message'];

  mysqli_query($conn, "INSERT INTO message (mess_description, mess_date, mess_patientsID) VALUES ('$message', '$datemessage', '$patient_id')");

  $message = "New Message Save Successfully!";
  header("location:congratulations.php?goto_page=user_message.php&message=$message");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
 <?php include 'config/css.php';?>

 
 <?php include 'config/data_css.php';?>
 <title>Patient Record - SAOMS</title>
</head>
<body class="hold-transition sidebar-mini dark-mode layout-fixed layout-navbar-fixed">
  <!-- Site wrapper -->
  <div class="wrapper">
    <?php include 'include/header.php';
include 'include/sidebar.php';?>  
    <div class="content-wrapper">
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Patient Record</h1>
            </div>
          </div>
        </div>
      </section>

    <section class="content">
      <div class="card card-outline card-primary rounded-0 shadow">
        <div class="card-header">
          <h3 class="card-title">All Patient Record</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            
          </div>
        </div>
        <div class="card-body">
         <div class="row table-responsive">

          <table id="all_appoint" 
          class="table table-striped dataTable table-bordered dtr-inline" 
          role="grid" aria-describedby="all_medicines_info">
          <colgroup>
            <col hidden width="5%">
            <col width="15%">
            <col width="15%">
            <col width="5%">
            <col width="10%">
            <col width="15%">
            <col width="10%">
            <col width="10%">
            <col width="10%">
            <col width="10%">
          </colgroup>

          <thead>
            <tr>
             <th hidden class="text-center">S.No</th>
             <th>Patient's Name</th>
             <th>Address</th>
             <th>Gender</th>
             <th>Phone No.</th>
             <th>Left Eye</th>
             <th>Right Eye</th>
             <th>Findings</th>
             <th>Prescription</th>
             <th class="text-center">Action</th>
           </tr>
         </thead>
         <?php 
          $query = mysqli_query($conn, "SELECT * FROM check_up, patients WHERE patients.patients_id = check_up.check_patientsID");
          while ($row = mysqli_fetch_array($query)) {

          ?>
         <tbody>
           <tr>
             <td hidden class="text-center"><?php echo $row['check_id'];?></td>
             <td><?php echo $row['patients_name'];?></td>
             <td><?php echo $row['patients_address'];?></td>
             <td><?php echo $row['patients_gender'];?></td>
             <td><?php echo $row['patients_contact'];?></td>
             <td><?php echo $row['check_lefteye'];?>/100</td>
             <td><?php echo $row['check_righteye'];?>/100</td>
             <td><?php echo $row['check_findings'];?></td>
             <td><?php echo $row['check_prescription'];?></td>
             <td class="text-center">
              <a href="#?id=<?php echo $row['check_id'];?>" 
               class="btn btn-danger btn-sm btn-flat">
               <i class="fa fa-trash"></i>
             </a>
             <a href="patients_record_view.php?id=<?php echo $row['check_id'];?>" 
               class="btn btn-primary btn-sm btn-flat">
               <i class="fa fa-eye"></i>
             </a>
           </td>
         </tr>
       <?php }; ?>
     </tbody>
   </table>
 </div>
</div>
</div>
</section>
</div>
<?php 
include 'include/footer.php';

$message = '';
if(isset($_GET['message'])) {
  $message = $_GET['message'];
}
?>  
</div>

<?php include 'config/js.php'; ?>
<?php include 'config/data_js.php'; ?>
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

<script>
  showMenuSelected("#mnu_patients", "#mi_record");

  var message = '<?php echo $message;?>';

  if(message !== '') {
    showCustomMessage(message);
  }
  $('#date_message').datetimepicker({
        format: 'L'
    })
  $(document).ready(function(){
    $('#all_appoint').dataTable();
  })
</script>
</body>
</html>