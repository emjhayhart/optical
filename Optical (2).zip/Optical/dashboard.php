<?php 
session_start();
include 'config/connection.php';

$userID = $_SESSION["id"];

$query = mysqli_query($conn, "SELECT * FROM patients WHERE patients_gender = 'Male'");
$male = mysqli_num_rows($query);

$qquery = mysqli_query($conn, "SELECT * FROM patients WHERE patients_gender = 'Female'");
$female = mysqli_num_rows($qquery);

$query1 = mysqli_query($conn, "SELECT * FROM patients");
$checkup = mysqli_num_rows($query1);

$query2 = mysqli_query($conn, "SELECT sum(pay_checkup) AS totalcheck FROM payment");
$income = mysqli_fetch_array($query2);
$totalPrice = $income['totalcheck'];

$query4 = mysqli_query($conn, "SELECT sum(eye_price) AS price FROM payment, eyewear_sell WHERE payment.pay_eyeID = eyewear_sell.eye_id");
$payment = mysqli_fetch_array($query4);
$totpayment = $payment['price'];

$totalpayment = $totalPrice + $totpayment;

$appoint = 0;
$query3 = mysqli_query($conn, "SELECT * FROM schedule_list");
$appoint = mysqli_num_rows($query3);

?>
<!DOCTYPE html>
<html>
<head>
	<?php include 'config/css.php'; ?>
	<title>Dashboard - SAOMS</title>
</head>
<body class="hold-transition sidebar-mini dark-mode layout-fixed layout-navbar-fixed">

<div class="wrapper">
	<?php 

	include 'include/header.php';
	include 'include/sidebar.php';

	?>

	<div class="content-wrapper">
		<section class="content-header">
			<div class="container-fluid">
				<div class="row mb-2">
					<div class="col-sm-6">
						<h1>Dashboard</h1>
					</div>
				</div>
			</div>
		</section>

		<section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-3 col-3">
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo $male; ?></h3>
                <p>Total Number Patients Male</p>
              </div>
              <div class="icon">
                <i class="fa fa-male"></i>
              </div>
             
            </div>
          </div>
          <div class="col-lg-3 col-3">
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo $female; ?></h3>
                <p>Total Number Patients Female</p>
              </div>
              <div class="icon">
                <i class="fa fa-female"></i>
              </div>
             
            </div>
          </div>
          <div class="col-lg-3 col-3">
            <div class="small-box bg-purple">
              <div class="inner">
                <h3><?php echo $appoint; ?></h3>
                <a href="appointment.php">
                <p style="color:white;">Appointment Requests</p>
              </a>
              </div>
              <div class="icon">
                <i class="fa fa-calendar-week"></i>
              </div>
             
            </div>
          </div>
          <div class="col-lg-3 col-3">
            <div class="small-box bg-fuchsia text-reset">
              <div class="inner">
                <h3><?php echo $checkup; ?></h3>
                <p>Check-ups</p>
              </div>
              <div class="icon">
                <i class="fa fa-calendar"></i>
              </div>
             
            </div>
          </div>
          <div class="col-lg-3 col-3">
            <div class="small-box bg-maroon text-reset">
              <div class="inner">
                <h3></h3>
                <h3><?php echo $totalpayment; ?></h3>
                <p>Current Income</p>
              </div>
              <div class="icon">
                <i class="fa fa-money-bill"></i>
              </div>
             
            </div>
          </div>
          <div class="col-lg-3 col-3">
            <div class="small-box bg-maroon text-reset">
              <div class="inner">
                <h3></h3>
                <h3><?php echo $message; ?></h3>
                <p>Overall Patients Satisfaction</p>
              </div>
              <div class="icon">
                <i class="fa fa-user-injured"></i>
              </div>
             
            </div>
          </div>
        </div>
      </div>
    </section>
	</div>
  <?php include 'include/footer.php'; ?>
</div>

<?php include 'config/js.php'; ?>
<script>
  $(function(){
    showMenuSelected("#mnu_dashboard", "");
  })
</script>
</body>
</html>