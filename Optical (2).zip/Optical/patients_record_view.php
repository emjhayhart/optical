<?php
session_start();

include 'config/connection.php';

$checkID = $_REQUEST['id'];

$query1 = mysqli_query($conn, "SELECT * FROM patients, check_up WHERE patients.patients_id = check_up.check_patientsID AND check_id = '$checkID'");
$row1 = mysqli_fetch_array($query1);
$check_id = $row1['check_id'];
$patientID = $row1['patients_id'];
$finding = $row1['check_findings'];
$prescription = $row1['check_prescription'];


$query = mysqli_query($conn, "SELECT * FROM patients WHERE patients_id = '$patientID'");
$row = mysqli_fetch_array($query);

$gender = $row['patients_gender'];
$patientName = $row['patients_name'];
$dob = $row['patients_dateofbirth']; 
$patients_ID = $row['patients_id'];
$patientcon = $row['patients_contact'];
$patientadd = $row['patients_address']; 

?>

<!DOCTYPE html>
<html lang="en">
<head>
 <?php include 'config/css.php';?>

 
 <?php include 'config/data_css.php';?>
 <title>View Record - SAOMS</title>
</head>
<body class="hold-transition sidebar-mini dark-mode layout-fixed layout-navbar-fixed">
  <!-- Site wrapper -->
  <div class="wrapper">
    <?php include 'include/header.php';
include 'include/sidebar.php';?>  
    <div class="content-wrapper">
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>View Record</h1>
            </div>
          </div>
        </div>
      </section>

    <section class="content">
      <div class="card card-outline card-primary rounded-0 shadow">
        <div class="card-header">
          <h3 class="card-title">View Record</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            
          </div>
        </div>
        <div class="card-body">
          <form method="post">
         <div class="row col-lg-10">
            <input type="hidden" name="patientid" value="<?php echo $patients_ID; ?>">
            <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                 <label>Patient Name</label>
                 <input type="text" id="patient" name="patient" required="required"
                        class="form-control form-control-sm rounded-0" value="<?php echo $patientName; ?>" />
              </div>
              <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                 <label>Gender</label>
                 <select class="form-control form-control-sm rounded-0" id="gender" 
                name="gender">
                 <?php echo getGender($gender);?>
                </select>
              </div>
              <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                 <label>Address</label>
                 <input type="text" id="address" name="address" required="required"
                        class="form-control form-control-sm rounded-0" value="<?php echo $patientadd; ?>" />
              </div>
              <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                 <label>Contact No.</label>
                 <input type="text" id="contact" name="contact" required="required"
                        class="form-control form-control-sm rounded-0" value="<?php echo $patientcon; ?>" />
              </div>
              <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 form-outline">
                 <label>Findings</label>
                 <textarea id="findings" name="findings" required="required"
                        class="form-control form-control-sm rounded-0"/>
                        <?php echo $finding; ?>
                  </textarea>
              </div>
              <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                 <label>Prescription</label>
                 <textarea id="prescription" name="prescription" required="required"
                        class="form-control form-control-sm rounded-0" />
                        <?php echo $prescription; ?>
                  </textarea>
              </div>
         </div>
         <div class="clearfix">&nbsp;</div>
            <div class="row" style="padding-left:180px;">
              <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                <button type="submit" id="save_update" name="save_update" class="btn btn-primary btn-sm btn-flat btn-block">Edit</button>
              </div>
              <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12" style="margin-left: 50px;">
                <a href="patients_record_print.php?id=<?php echo $check_id; ?>" type="submit" class="btn btn-primary btn-sm btn-flat btn-block">Print Record</a>
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
    <section class="content">
      <div class="card card-outline card-primary rounded-0 shadow">
        <div class="card-header">
          <h3 class="card-title">Eyewear</h3>
            <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            
          </div>
          </div>
          <div class="card-body">
            <div class="row col-lg-10" style="margin-left:150px;">
              <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                <label>Eyewear</label>
                  <?php 
                    $query2 = mysqli_query($conn, "SELECT * FROM check_up, eyewear_sell WHERE check_up.check_eyeID = eyewear_sell.eye_id AND check_patientsID = '$patients_ID'");
                    $row2 = mysqli_fetch_array($query2);
                      $wearID = $row2['check_eyeID'];

                    $query3 = mysqli_query($conn, "SELECT * FROM eyewear_sell WHERE eye_id = '$wearID'");
                    $row3 = mysqli_fetch_array($query3);
                    $eyename = $row3['eye_name'];
                    $eyeID = $row3['eye_id']
                  ?>
                  <input type="text" name="eyewear" class="form-control form-control-sm rounded-0" value="<?php echo $eyename; ?>">
              </div>
            </div>
            <div class="clearfix">&nbsp;</div>
            <div class="row" style="margin-left:270px;">
              <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                <a href="patients_record_eyewear_print.php?id=<?php echo $eyeID; ?>" type="submit" id="save_Patient" name="save_Patient" class="btn btn-primary btn-sm btn-flat btn-block">Print Claim Slip</a>
              </div>
          </div>
        </div>
      </div>
    </section>
    <section class="content">
      <div class="card card-outline card-primary rounded-0 shadow">
        <div class="card-header">
          <h3 class="card-title">Official Receipt(O'R)</h3>
            <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            
          </div>
          </div>
          <div class="card-body">
            <div class="row col-lg-10" style="margin-left:150px;">
              <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                <label>Official Receipt</label>
                  <?php 
                    $query2 = mysqli_query($conn, "SELECT * FROM check_up, eyewear_sell WHERE check_up.check_eyeID = eyewear_sell.eye_id AND check_patientsID = '$patients_ID'");
                    $row2 = mysqli_fetch_array($query2);
                      $wearID = $row2['check_eyeID'];

                    $query3 = mysqli_query($conn, "SELECT * FROM eyewear_sell WHERE eye_id = '$wearID'");
                    $row3 = mysqli_fetch_array($query3);
                    $eyename = $row3['eye_name'];
                    $eyeID = $row3['eye_id']
                  ?>
                  <input type="text" name="eyewear" class="form-control form-control-sm rounded-0" value="<?php echo $eyename; ?>">
              </div>
            </div>
            <div class="clearfix">&nbsp;</div>
            <div class="row" style="margin-left:270px;">
              <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                <a href="official_receipt_print.php?id=<?php echo $eyeID; ?>" type="submit" id="save_Patient" name="save_Patient" class="btn btn-primary btn-sm btn-flat btn-block">Print O'R</a>
              </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php 
include 'include/footer.php';

$message = '';
if(isset($_GET['message'])) {
  $message = $_GET['message'];
}
?>  
</div>

<?php include 'config/js.php'; ?>
<?php include 'config/data_js.php'; ?>
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

<script>
  showMenuSelected("#mnu_patients", "#mi_record");

  var message = '<?php echo $message;?>';

  if(message !== '') {
    showCustomMessage(message);
  }
  $('#date_message').datetimepicker({
        format: 'L'
    })
  $(document).ready(function(){
    $('#all_appoint').dataTable();
  })
</script>
</body>
</html>
<?php
function getGender($gender = '') {
  $data = '<option value="">Select Gender</option>';
  
  $arr = array("Male", "Female", "Other");

  $i = 0;
  $size = sizeof($arr);

  for($i = 0; $i < $size; $i++) {
    if($gender == $arr[$i]) {
      $data = $data .'<option selected="selected" value="'.$arr[$i].'">'.$arr[$i].'</option>';
    } else {
    $data = $data .'<option value="'.$arr[$i].'">'.$arr[$i].'</option>';
    }
  }

  return $data;
}
?>