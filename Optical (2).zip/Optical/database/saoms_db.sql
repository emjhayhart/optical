-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2022 at 01:12 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saoms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkup`
--

CREATE TABLE `checkup` (
  `check_id` int(10) NOT NULL,
  `check_findings` varchar(100) NOT NULL,
  `check_prescription` varchar(50) NOT NULL,
  `check_patientsID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `checkup`
--

INSERT INTO `checkup` (`check_id`, `check_findings`, `check_prescription`, `check_patientsID`) VALUES
(1, '', 'Amoxicilin', 2),
(2, '', 'Amoxicilin', 2),
(3, '', 'Antibiotics', 1),
(4, 'halo', 'Amoxicilin', 2),
(5, 'red eye', 'Antibiotics', 1);

-- --------------------------------------------------------

--
-- Table structure for table `check_up`
--

CREATE TABLE `check_up` (
  `check_id` int(10) NOT NULL,
  `check_lefteye` int(10) NOT NULL,
  `check_righteye` int(10) NOT NULL,
  `check_findings` varchar(100) NOT NULL,
  `check_eyeID` int(10) NOT NULL,
  `check_prescription` varchar(50) NOT NULL,
  `check_patientsID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `check_up`
--

INSERT INTO `check_up` (`check_id`, `check_lefteye`, `check_righteye`, `check_findings`, `check_eyeID`, `check_prescription`, `check_patientsID`) VALUES
(1, 70, 80, 'Red Eye', 2, 'Antibiotics', 6),
(2, 80, 50, 'Blush Eye', 1, 'Mefenamic', 1),
(3, 50, 50, 'Redness of Right Eye', 2, 'Antibiotics', 9),
(4, 60, 40, 'Blur', 3, 'Amoxicilin', 7);

-- --------------------------------------------------------

--
-- Table structure for table `contact_lenses`
--

CREATE TABLE `contact_lenses` (
  `lens_id` int(10) NOT NULL,
  `lens_name` int(100) NOT NULL,
  `lens_price` int(10) NOT NULL,
  `lens_stock` int(10) NOT NULL,
  `lens_picture` varchar(255) NOT NULL,
  `lens_wearID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `eyeglasses`
--

CREATE TABLE `eyeglasses` (
  `eye_id` int(10) NOT NULL,
  `eye_name` varchar(50) NOT NULL,
  `eye_stock` int(10) NOT NULL,
  `eye_price` int(10) NOT NULL,
  `eye_picture` varchar(255) NOT NULL,
  `eye_wearID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `eyeglasses`
--

INSERT INTO `eyeglasses` (`eye_id`, `eye_name`, `eye_stock`, `eye_price`, `eye_picture`, `eye_wearID`) VALUES
(1, 'Ray Ban', 10, 0, '', 0),
(2, 'Grade A', 10, 1500, '', 0),
(3, 'Grade B', 10, 2000, '', 0),
(4, 'Ray Ban', 10, 1500, 'logo.jpg', 0),
(5, 'Ray Ban', 10, 2000, 'pngwing.com.png', 0),
(6, 'Grade C', 15, 1800, 'eyeglass 1.png', 0),
(7, 'Grade D', 15, 2200, 'eyeglass 2.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `eyewear`
--

CREATE TABLE `eyewear` (
  `wear_id` int(10) NOT NULL,
  `wear_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `eyewear`
--

INSERT INTO `eyewear` (`wear_id`, `wear_type`) VALUES
(1, 'Eyeglass'),
(2, 'Sunglass'),
(3, 'Contact Lense');

-- --------------------------------------------------------

--
-- Table structure for table `eyewear_sell`
--

CREATE TABLE `eyewear_sell` (
  `eye_id` int(10) NOT NULL,
  `eye_name` varchar(100) NOT NULL,
  `eye_stock` int(10) NOT NULL,
  `eye_price` int(10) NOT NULL,
  `eye_picture` varchar(255) NOT NULL,
  `eye_wearID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `eyewear_sell`
--

INSERT INTO `eyewear_sell` (`eye_id`, `eye_name`, `eye_stock`, `eye_price`, `eye_picture`, `eye_wearID`) VALUES
(1, 'Ray Ban', 10, 200, 'eyeglass 1.png', 2),
(2, 'Grade A', 5, 850, 'eyeglass.png', 1),
(3, 'Grade B', 10, 1000, 'eyeglass 2.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `image_id` int(10) NOT NULL,
  `image_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`image_id`, `image_file`) VALUES
(1, 'logo.jpg'),
(2, 'logo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `lefteye`
--

CREATE TABLE `lefteye` (
  `left_id` int(10) NOT NULL,
  `left_eye` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lefteye`
--

INSERT INTO `lefteye` (`left_id`, `left_eye`) VALUES
(1, 10),
(2, 20),
(3, 30),
(4, 40),
(5, 50),
(6, 60),
(7, 70),
(8, 80),
(9, 90),
(10, 100);

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `medi_id` int(10) NOT NULL,
  `medi_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`medi_id`, `medi_name`) VALUES
(1, 'Mefenamic'),
(2, 'Amoxicilin'),
(3, 'Antibiotics');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `mess_id` int(10) NOT NULL,
  `mess_description` varchar(500) NOT NULL,
  `mess_date` varchar(25) NOT NULL,
  `mess_patientsID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`mess_id`, `mess_description`, `mess_date`, `mess_patientsID`) VALUES
(4, 'Thanks for the service doc.', '2022:11:27', 7);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patients_id` int(10) NOT NULL,
  `patients_name` varchar(100) NOT NULL,
  `patients_address` varchar(100) NOT NULL,
  `patients_contact` varchar(11) NOT NULL,
  `patients_dateofbirth` varchar(25) NOT NULL,
  `patients_gender` varchar(25) NOT NULL,
  `patients_user` varchar(50) NOT NULL,
  `patients_pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patients_id`, `patients_name`, `patients_address`, `patients_contact`, `patients_dateofbirth`, `patients_gender`, `patients_user`, `patients_pass`) VALUES
(7, 'Rica Mahinay', 'Kaongkod, Madridejos, Cebu', '09383567038', '08/21/1996', 'Female', '09383567038', '32250170a0dca92d53ec9624f336ca24'),
(9, 'Ian Dalanon', 'Kabac, Bantayan, Cebu', '09383567038', '08/21/1996', 'Male', 'gwapo', '1e11bc788e2f7667054615fc83b18383');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `pay_id` int(10) NOT NULL,
  `pay_patientsID` int(10) NOT NULL,
  `pay_checkup` int(10) NOT NULL,
  `pay_eyeID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`pay_id`, `pay_patientsID`, `pay_checkup`, `pay_eyeID`) VALUES
(3, 9, 500, 2),
(6, 7, 500, 3);

-- --------------------------------------------------------

--
-- Table structure for table `righteye`
--

CREATE TABLE `righteye` (
  `right_id` int(10) NOT NULL,
  `right_eye` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `righteye`
--

INSERT INTO `righteye` (`right_id`, `right_eye`) VALUES
(1, 10),
(2, 20),
(3, 30),
(4, 40),
(5, 50),
(6, 60),
(7, 70),
(8, 80),
(9, 90),
(10, 100);

-- --------------------------------------------------------

--
-- Table structure for table `schedule_list`
--

CREATE TABLE `schedule_list` (
  `id` int(10) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `patientID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule_list`
--

INSERT INTO `schedule_list` (`id`, `name`, `description`, `start_datetime`, `end_datetime`, `address`, `contact`, `patientID`) VALUES
(7, 'Ian Dalanon', 'Red Eye', '2022-11-29 09:30:00', '2022-11-29 10:30:00', 'Kabac, Bantayan, Cebu', '09214876265', 9),
(8, 'Rica Mahinay', '.............', '2022-11-30 10:00:00', '2022-11-30 11:00:00', 'Tinago', '09214876265', 7);

-- --------------------------------------------------------

--
-- Table structure for table `sunglasses`
--

CREATE TABLE `sunglasses` (
  `sung_id` int(10) NOT NULL,
  `sung_name` varchar(100) NOT NULL,
  `sung_price` int(10) NOT NULL,
  `sung_stock` int(10) NOT NULL,
  `sung_picture` varchar(255) NOT NULL,
  `sung_wearID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sunglasses`
--

INSERT INTO `sunglasses` (`sung_id`, `sung_name`, `sung_price`, `sung_stock`, `sung_picture`, `sung_wearID`) VALUES
(1, 'Grade A', 1500, 10, 'eyeglass 1.png', 0),
(2, 'Grade B', 2000, 15, 'eyeglass 2.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(10) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_pass` varchar(50) NOT NULL,
  `user_displayName` varchar(50) NOT NULL,
  `user_picture` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_pass`, `user_displayName`, `user_picture`) VALUES
(1, 'admin', 'admin', 'administrator', ''),
(3, 'handsome', '32250170a0dca92d53ec9624f336ca24', 'Handsome Guy', 'logo.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `checkup`
--
ALTER TABLE `checkup`
  ADD PRIMARY KEY (`check_id`);

--
-- Indexes for table `check_up`
--
ALTER TABLE `check_up`
  ADD PRIMARY KEY (`check_id`);

--
-- Indexes for table `contact_lenses`
--
ALTER TABLE `contact_lenses`
  ADD PRIMARY KEY (`lens_id`);

--
-- Indexes for table `eyeglasses`
--
ALTER TABLE `eyeglasses`
  ADD PRIMARY KEY (`eye_id`);

--
-- Indexes for table `eyewear`
--
ALTER TABLE `eyewear`
  ADD PRIMARY KEY (`wear_id`);

--
-- Indexes for table `eyewear_sell`
--
ALTER TABLE `eyewear_sell`
  ADD PRIMARY KEY (`eye_id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `lefteye`
--
ALTER TABLE `lefteye`
  ADD PRIMARY KEY (`left_id`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`medi_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`mess_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patients_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `righteye`
--
ALTER TABLE `righteye`
  ADD PRIMARY KEY (`right_id`);

--
-- Indexes for table `schedule_list`
--
ALTER TABLE `schedule_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sunglasses`
--
ALTER TABLE `sunglasses`
  ADD PRIMARY KEY (`sung_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `checkup`
--
ALTER TABLE `checkup`
  MODIFY `check_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `check_up`
--
ALTER TABLE `check_up`
  MODIFY `check_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contact_lenses`
--
ALTER TABLE `contact_lenses`
  MODIFY `lens_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eyeglasses`
--
ALTER TABLE `eyeglasses`
  MODIFY `eye_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `eyewear`
--
ALTER TABLE `eyewear`
  MODIFY `wear_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `eyewear_sell`
--
ALTER TABLE `eyewear_sell`
  MODIFY `eye_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `image_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lefteye`
--
ALTER TABLE `lefteye`
  MODIFY `left_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `medi_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `mess_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patients_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pay_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `righteye`
--
ALTER TABLE `righteye`
  MODIFY `right_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `schedule_list`
--
ALTER TABLE `schedule_list`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sunglasses`
--
ALTER TABLE `sunglasses`
  MODIFY `sung_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
