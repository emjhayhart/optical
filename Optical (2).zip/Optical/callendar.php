<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSS for full calender -->
	<link rel="stylesheet" href="plugins/fullcalendar/fullcalendar.min.css">
	<link rel="stylesheet" href="plugins/fullcalendar/fullcalendar.print.css" media="print">
	<!-- JS for jQuery -->
	<script src="plugins/jquery/jquery.min.js"></script>
	<!-- JS for full calender -->
	<script src="plugins/moment/moment.min.js"></script>
	<script src="plugins/fullcalendar/fullcalendar.min.js"></script>
	<!-- bootstrap css and js -->
	<script src="plugins/bootstrap/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">
	<title></title>
	
</head>
<body>
<div id="calendar"></div>
</body>
<script>
	var calendar;
    var Calendar = FullCalendar.Calendar;
    var events = [];
    $(function() {
        if (!!scheds) {
            Object.keys(scheds).map(k => {
                var row = scheds[k]
                events.push({ id: row.id, title: row.title, start: row.start_datetime, end: row.end_datetime });
            })
        }
        var date = new Date()
        var d = date.getDate(),
            m = date.getMonth(),
            y = date.getFullYear()
 
        calendar = new Calendar(document.getElementById('calendar'), {
            headerToolbar: {
                left: 'prev,next today',
                right: 'dayGridMonth,dayGridWeek,list',
                center: 'title',
            }
        });
	</script>
</html>